Troubadour image: https://www.moyenagepassion.com/index.php/2019/02/28/chant-de-croisade-les-vers-du-lavoir-ou-lappel-de-marcabru-a-la-reconquista/
Battle image: https://manuscriptminiatures.com/4937/14872
Trial image: http://socialsciences.exeter.ac.uk/media/universityofexeter/collegeofsocialsciencesandinternationalstudies/lawimages/images/carousel/bracton_chivalry_court-(668x359).jpg
